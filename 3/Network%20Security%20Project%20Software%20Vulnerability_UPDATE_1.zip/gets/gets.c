#include <stdio.h>

void hacked() {
  puts("Hacked!!");
}

int main() {
  char str[10];
  gets(str);
}
